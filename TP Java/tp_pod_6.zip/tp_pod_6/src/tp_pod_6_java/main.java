package tp_pod_6_java;
import java.util.ArrayList;
import java.util.List;

abstract class Cafe {
    protected List<Ingrediente> ingredientes;

    public Cafe() {
        this.ingredientes = new ArrayList<>();
    }

    public int basePrice() {
        return 15;
    }

    public abstract int sizePrice();

    public int ingredientesPrice() {
        return ingredientes.stream().mapToInt(Ingrediente::price).sum();
    }

    public int price() {
        return basePrice() + sizePrice() + ingredientesPrice();
    }

    public int priceSinNada() {
        return basePrice() + sizePrice();
    }

    public void add(Ingrediente ingrediente) {
        ingredientes.add(ingrediente);
    }
}

class CafeChico extends Cafe {
    @Override
    public int sizePrice() {
        return 5;
    }
}

class CafeMediano extends Cafe {
    @Override
    public int sizePrice() {
        return 7;
    }
}

class CafeGrande extends Cafe {
    @Override
    public int sizePrice() {
        return 10;
    }
}

abstract class Ingrediente {
    public abstract int price();
}

class Chocolate extends Ingrediente {
    @Override
    public int price() {
        return 7;
    }
}

class Crema extends Ingrediente {
    @Override
    public int price() {
        return 10;
    }
}

class Rocklets extends Ingrediente {
    @Override
    public int price() {
        return 15;
    }
}

class Caramelo extends Ingrediente {
    @Override
    public int price() {
        return 12;
    }
}

class Azucar extends Ingrediente {
    @Override
    public int price() {
        return 1;
    }
}
class CafeTest {

    public static void main(String[] args) {
        testCafeMedianoSolo();
        testCafeChicoSolo();
        testCafeGrandeSolo();
        testCafeChicoTodo();
        testCafeGrandeTodo();
    }

    static void assertEquals(int expected, int actual, String message) {
        if (expected != actual) {
            System.out.println("Test fallido: " + message + " Esperado " + expected + " pero se obtuvo " + actual);
        } else {
            System.out.println("El Test paso: " + message);
        }
    }

    static void testCafeMedianoSolo() {
        CafeMediano emptyMediumCoffee = new CafeMediano();
        assertEquals(22, emptyMediumCoffee.priceSinNada(), "El cafe mediano solo esta 22");
    }

    static void testCafeChicoSolo() {
        CafeChico emptySmallCoffee = new CafeChico();
        assertEquals(20, emptySmallCoffee.priceSinNada(), "El cafe chico solo esta 20");
    }

    static void testCafeGrandeSolo() {
        CafeGrande emptyLargeCoffee = new CafeGrande();
        assertEquals(25, emptyLargeCoffee.priceSinNada(), "El cafe grande solo esta 25");
    }

    static void testCafeChicoTodo() {
        CafeChico cafeChico = new CafeChico();
        cafeChico.add(new Chocolate());
        cafeChico.add(new Chocolate());
        cafeChico.add(new Chocolate());
        cafeChico.add(new Crema());
        cafeChico.add(new Caramelo());
        cafeChico.add(new Azucar());
        cafeChico.add(new Rocklets());
        assertEquals(79, cafeChico.price(), "El cafe chico con esos ingredientes esta 79");
    }

    static void testCafeGrandeTodo() {
        CafeGrande cafeGrande = new CafeGrande();
        cafeGrande.add(new Chocolate());
        cafeGrande.add(new Crema());
        cafeGrande.add(new Caramelo());
        cafeGrande.add(new Azucar());
        cafeGrande.add(new Rocklets());
        assertEquals(70, cafeGrande.price(), "El cafe grande con esos ingredientes esta 70");
    }
}

public class main {
    public static void main(String[] args) {
        CafeTest.main(args);
    }
}
